package com.example.migrosapp

import java.io.Serializable

data class Yemekler(var id: Int,
                   var ad: String,
                   var resim: String,
                   var fiyat: Int) : Serializable { //veri transferi için
}