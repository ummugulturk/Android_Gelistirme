package com.example.migrosapp

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com. example. migrosapp. databinding. CardTasarimBinding

class YemeklerAdapter(var mContext: Context,var yemeklerListesi: List<Yemekler>)
    : RecyclerView.Adapter<YemeklerAdapter.CardTasarimTutucu>() {

    inner class CardTasarimTutucu(var tasarim: CardTasarimBinding) : RecyclerView.ViewHolder(tasarim.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): com.example.migrosapp.YemeklerAdapter.CardTasarimTutucu {
        var binding = CardTasarimBinding.inflate(LayoutInflater.from(mContext), parent, false)
        return CardTasarimTutucu(binding)
    }

    override fun onBindViewHolder(holder: com.example.migrosapp.YemeklerAdapter.CardTasarimTutucu, position: Int) {
        val yemek = yemeklerListesi.get(position)
        val t = holder.tasarim
        t.textViewFiyat.text = "${yemek.fiyat} ₺"
        t.imageViewFilm.setImageResource(
            mContext.resources.getIdentifier(yemek.resim,"drawable",mContext.packageName)
        )

        t.buttonSepet.setOnClickListener {
            Snackbar.make(it,"${yemek.ad} sepete eklendi", Snackbar.LENGTH_SHORT).show()
        }

        t.cardViewYemek.setOnClickListener {
            val gecis= AnasayfaFragmentDirections.detayGecis(yemekNesnesi = yemek)
            Navigation.findNavController(it).navigate(gecis)
        }
    }

    override fun getItemCount(): Int {
        return yemeklerListesi.size
    }
}