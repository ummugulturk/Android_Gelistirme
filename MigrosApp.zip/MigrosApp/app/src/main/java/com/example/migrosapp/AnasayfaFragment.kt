package com.example.migrosapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.migrosapp.databinding.FragmentAnasayfaBinding

class AnasayfaFragment : Fragment() {
    private lateinit var binding: FragmentAnasayfaBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentAnasayfaBinding.inflate(inflater, container, false)

        val yemeklerListesi = ArrayList<Yemekler>()
        val y1 = Yemekler(1,"Django","django",24)
        val y2 = Yemekler(2,"Interstellar","interstellar",32)
        val y3 = Yemekler(3,"Inception","inception",16)
        val y4 = Yemekler(4,"The Hateful Eight","thehatefuleight",28)
        val f5 = Yemekler(5,"The Pianist","thepianist",18)
        val f6 = Yemekler(6,"Anadoluda","anadoluda",10)
        yemeklerListesi.add(y1)
        yemeklerListesi.add(y2)
        yemeklerListesi.add(y3)
        yemeklerListesi.add(y4)
        yemeklerListesi.add(f5)
        yemeklerListesi.add(f6)

        val filmlerAdapter = YemeklerAdapter(requireContext(),yemeklerListesi)
        binding.yemeklerRv.adapter = filmlerAdapter

        binding.yemeklerRv.layoutManager=
            StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)


        return binding.root
    }
}