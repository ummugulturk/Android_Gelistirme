package com.example.pagetransition

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx. navigation. fragment. findNavController
import com.example.pagetransition.databinding.FragmentSayfaYBinding

class sayfaYFragment : Fragment() {
    private lateinit var binding: FragmentSayfaYBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentSayfaYBinding.inflate(inflater, container, false)

        var geriTusu = object : OnBackPressedCallback(true){ //true=geri dönüş aktif değil
            override fun handleOnBackPressed() {
                Log.e("Sayfa Y", "Geri tuşu çalıştı")
                findNavController().navigate(R.id.yToAnasayfa)
                isEnabled=false

            }
        }

        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner,geriTusu)

        return binding.root
    }
}