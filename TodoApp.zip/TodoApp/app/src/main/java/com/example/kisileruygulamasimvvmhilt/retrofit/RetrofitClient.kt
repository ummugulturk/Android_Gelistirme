package com.example.kisileruygulamasimvvmhilt.retrofit

import com.example.kisileruygulamasimvvmhilt.data.entity.CRUDCevap
import retrofit2.http. POST
import com. example. kisileruygulamasimvvmhilt. data. entity. KisilerCevap
import retrofit2.http. GET
import retrofit2.http. FormUrlEncoded
import retrofit2.http. Field


interface KisilerDao2 {
    //from retrofit library
    @GET("kisiler/tum_kisiler.php")
    suspend fun kisileriYukle() : KisilerCevap

    @POST("kisiler/insert_kisiler.php")
    @FormUrlEncoded
    suspend fun kaydet(@Field("kisi_ad") kisi_ad: String,
                       @Field("kisi_tel") kisi_tel: String ) : CRUDCevap
}