package com.example.kisileruygulamasimvvmhilt.data.entity

data class CRUDCevap(var success: Int,
                     var message: String) {
}