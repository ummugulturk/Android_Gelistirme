package com.example.kisileruygulamasimvvmhilt.di

import android.content.Context
import androidx.annotation.UiContext
import com. example. kisileruygulamasimvvmhilt. data. repo. KisilerRepository
import com.example.kisileruygulamasimvvmhilt.data.datasource.KisilerDataSource
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

import com. example. kisileruygulamasimvvmhilt. retrofit. KisilerDao


@Module
@InstallIn(SingletonComponent::class)
class AppModule {
    @Provides
    @Singleton
    fun provideKisilerRepository(kisilerDataSource: KisilerDataSource) : KisilerRepository{
        return KisilerRepository(kisilerDataSource)
    }

    @Provides
    @Singleton
    fun provideKisilerDataSource(kisilerDao: KisilerDao) : KisilerDataSource {
        return KisilerDataSource(kisilerDao)
    }

}

