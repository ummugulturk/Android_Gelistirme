package com.example.kisileruygulamasimvvmhilt.ui.adapter

import android.content.Context
import com. example. kisileruygulamasimvvmhilt. ui. viewmodel. AnasayfaViewModel
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import com.example.kisileruygulamasimvvmhilt.data.entity.Kisiler
import com.example.kisileruygulamasimvvmhilt.databinding.CardTasarimBinding
import com.example.kisileruygulamasimvvmhilt.ui.fragment.AnasayfaFragmentDirections
import com.example.kisileruygulamasimvvmhilt.ui.viewmodel.AnasayfaViewModel
import com.example.kisileruygulamasimvvmhilt.utils.gecisYap
import com.google.android.material.snackbar.Snackbar
import com. example. kisileruygulamasimvvmhilt. databinding. CardTasarimBinding

class KisilerAdapter(var mContext: Context,
                     var kisilerListesi: List<Kisiler>,
                     var viewModel: AnasayfaViewModel)
    : RecyclerView.Adapter<KisilerAdapter.CardTasarimTutucu>() {

    inner class CardTasarimTutucu(var tasarim: CardTasarimBinding) : RecyclerView.ViewHolder(tasarim.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardTasarimTutucu {
        val tasarim = CardTasarimBinding.inflate(LayoutInflater.from(mContext), parent, false)
        return CardTasarimTutucu(tasarim)
    }

    override fun onBindViewHolder(holder: CardTasarimTutucu, position: Int) {
        val kisi = kisilerListesi.get(position)//0,1,2
        val t = holder.tasarim
        t.textViewKisiAd.text = kisi.kisi_ad
        t.textViewKisiTel.text = kisi.kisi_tel

        t.cardViewSatir.setOnClickListener {
            val gecis = AnasayfaFragmentDirections.kisiDetayGecis(kisi = kisi)
            Navigation.gecisYap(it,gecis)
        }

        t.imageViewSil.setOnClickListener {
            Snackbar.make(it,"${kisi.kisi_ad} silinsin mi?", Snackbar.LENGTH_SHORT)
                .setAction("EVET") {
                    viewModel.sil(kisi.kisi_id)
                }.show()
        }
    }

    override fun getItemCount(): Int {
        return kisilerListesi.size
    }
}