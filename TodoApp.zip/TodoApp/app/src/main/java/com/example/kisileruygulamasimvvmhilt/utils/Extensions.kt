package com.example.kisileruygulamasi.utils

import android.view.View
import androidx.navigation.NavDirections
import androidx.navigation.Navigation
import com.example.kisileruygulamasi.R

fun Navigation.gecisYap(it: View, id: Int){ //infix için
    findNavController(it).navigate(id)
}

//overloading
fun Navigation.gecisYap(it: View, id: NavDirections){ //infix için
    findNavController(it).navigate(id)
}