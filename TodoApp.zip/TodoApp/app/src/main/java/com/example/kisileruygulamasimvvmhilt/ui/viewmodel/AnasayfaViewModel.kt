package com.example.kisileruygulamasimvvmhilt.ui.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.kisileruygulamasimvvmhilt.data.entity.Kisiler
import com.example.kisileruygulamasimvvmhilt.data.repo.KisilerRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AnasayfaViewModel @Inject constructor(var kisilerRepository:KisilerRepository) : ViewModel() {
    var kisilerListesi = MutableLiveData<List<Kisiler>>()

    init {
        kisileriYukle()
    }

    //silme adapterda oluyor ama arayüzde silinme kodu burada
    fun sil(kisi_id:Int){
        CoroutineScope(Dispatchers.Main).launch {
            kisilerRepository.sil(kisi_id)
            kisileriYukle()//sildikten sonra kalanları gösterir
        }
    }

    fun kisileriYukle() {
        CoroutineScope(Dispatchers.Main).launch {
            kisilerListesi.value = kisilerRepository.kisileriYukle()//Tetikleme

            try {
                kisilerListesi.value= kisilerRepository.kisileriYukle()
            }catch (e: Exception){}
        }
    }

    fun ara(aramaKelimesi:String){
        CoroutineScope(Dispatchers.Main).launch {
            kisilerListesi.value = kisilerRepository.ara(aramaKelimesi)//Tetikleme

            try {
                kisilerListesi.value= kisilerRepository.ara(aramaKelimesi)
            }catch (e: Exception){}
        }
    }
}