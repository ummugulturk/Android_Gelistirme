package com.example.kisileruygulamasimvvmhilt.data.entity

class KisilerCevap {
}